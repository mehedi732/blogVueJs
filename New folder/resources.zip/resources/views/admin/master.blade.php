@include('admin.includes.header')
 @include('admin.includes.nav')
 @include('admin.includes.sidebar')
 <div class="content-wrapper mt-5">
    <main-component></main-component>
</div>
  @include('admin.includes.footer')
